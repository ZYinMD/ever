'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'h2';
var width = 640;
var height = 512;
var ligatures = [];
var unicode = 'f314';
var svgPathData = 'M480.776 352.493h124.659c8.837 0 16 7.163 16 16V400c0 8.837-7.163 16-16 16H418.863c-8.053 0-14.853-5.993-15.873-13.981-1.112-8.71-1.708-14.601-1.708-20.982 0-113.106 142.094-134.46 142.094-187.461 0-23.744-19.197-34.372-38.224-34.372-18.898 0-33.069 11.294-43.838 26.397-4.988 6.994-14.706 8.641-21.855 3.878l-28.274-18.837c-7.179-4.783-9.222-14.365-4.74-21.736 22.015-36.198 59.594-57.917 103.415-57.917 59.187 0 106.866 37.127 106.866 97.879.002 95.615-121.174 119.02-135.95 163.625zm-313.101 21.541V400c0 8.837-7.163 16-16 16H38.365c-8.837 0-16-7.163-16-16v-25.966c0-8.837 7.163-16 16-16h20.394v-203.64H38.365c-8.837 0-16-7.163-16-16V112c0-8.837 7.163-16 16-16h113.31c8.837 0 16 7.163 16 16v26.394c0 8.837-7.163 16-16 16h-20.822v71.767h122.29v-71.767h-20.822c-8.837 0-16-7.163-16-16V112c0-8.837 7.163-16 16-16h113.31c8.837 0 16 7.163 16 16v26.394c0 8.837-7.163 16-16 16h-20.393v203.64h20.393c8.837 0 16 7.163 16 16V400c0 8.837-7.163 16-16 16h-113.31c-8.837 0-16-7.163-16-16v-25.966c0-8.837 7.163-16 16-16h20.822v-70.91h-122.29v70.91h20.822c8.837 0 16 7.164 16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faH2 = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;