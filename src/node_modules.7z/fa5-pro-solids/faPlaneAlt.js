'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'plane-alt';
var width = 576;
var height = 512;
var ligatures = [];
var unicode = 'f3de';
var svgPathData = 'M472 200H347.713l-38.614-72H324c6.627 0 12-5.373 12-12V76c0-6.627-5.373-12-12-12h-49.225L243.514 5.711A12 12 0 0 0 233.294 0h-57.787c-7.85 0-13.586 7.413-11.616 15.012l33.306 185.391c-32.631.973-63.109 3.697-89.882 7.79l-39.82-66.366a12 12 0 0 0-10.29-5.826H14.638c-7.573 0-13.252 6.928-11.767 14.353l16.561 82.805C6.949 240.135 0 247.865 0 256.001s6.949 15.866 19.431 22.842l-16.56 82.803C1.386 369.072 7.065 376 14.638 375.999l42.568-.002c4.215 0 8.121-2.212 10.289-5.826l39.819-66.362c26.773 4.093 57.252 6.817 89.883 7.79l-33.306 185.389c-1.97 7.599 3.766 15.012 11.616 15.012h57.787a12 12 0 0 0 10.22-5.711L274.775 448H324c6.627 0 12-5.373 12-12v-40c0-6.627-5.373-12-12-12h-14.901l38.614-72H472c57.438 0 104-25.072 104-56s-46.562-56-104-56z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faPlaneAlt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;