'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'leaf-maple';
var width = 512;
var height = 512;
var ligatures = [];
var unicode = 'f6f6';
var svgPathData = 'M503.58 166.05l-37.24-22.34 9.86-88.78c1.23-11.04-8.1-20.37-19.14-19.14l-88.78 9.86-22.33-37.23c-6.63-11.05-22.57-11.26-29.49-.39l-89.6 140.79 16.58-64.84c2.8-12.58-8.62-23.7-21.12-20.58L196.6 77.22l-45.3-51.33c-6.94-8.67-20.13-8.67-27.07 0l-45.3 51.33L53.2 63.41c-12.5-3.12-23.92 8-21.12 20.58l33.04 160.19-37.09 15.89c-14.01 6-14.01 25.86 0 31.87l102.75 44.04L9.37 457.38c-12.5 12.5-12.5 32.75 0 45.25C15.62 508.88 23.81 512 32 512s16.37-3.12 22.62-9.38L257 300.25l-66.1 115.67 29.16 68.05c6.01 14.01 25.87 14.01 31.87 0l15.89-37.09 160.19 33.04c12.58 2.79 23.7-8.62 20.58-21.12l-13.81-25.72 51.32-45.3c8.67-6.94 8.67-20.13 0-27.07l-51.32-45.3 13.81-25.72c3.12-12.5-8-23.92-20.58-21.12l-64.84 16.58 140.79-89.59c10.88-6.94 10.67-22.88-.38-29.51z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faLeafMaple = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;