'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'scarecrow';
var width = 448;
var height = 512;
var ligatures = [];
var unicode = 'f70d';
var svgPathData = 'M224 448.1c-7.72 0-15.4-1.92-22.21-5.55l-9.79-5.22V496c0 8.84 7.16 16 16 16h32c8.84 0 16-7.16 16-16v-58.67l-9.79 5.22A47.383 47.383 0 0 1 224 448.1zm221.66-261.76L419.31 160l18.34-18.34c5.04-5.04 1.47-13.66-5.66-13.66H314.12c3.57-10.05 5.88-20.72 5.88-32 0-53.02-42.98-96-96-96s-96 42.98-96 96c0 11.28 2.3 21.95 5.88 32H16c-7.13 0-10.7 8.62-5.66 13.66L28.69 160 2.34 186.34c-3.12 3.12-3.12 8.19 0 11.31L28.69 224l-18.34 18.34C5.3 247.38 8.87 256 16 256h106.13l-25.9 141.34c-2.15 12.9 11.24 22.79 22.94 16.94l32.71-24.25a16.022 16.022 0 0 1 17.06-1.27l47.91 25.55c4.47 2.38 9.84 2.38 14.31 0l47.91-25.55a15.982 15.982 0 0 1 17.06 1.27l32.71 24.25c11.7 5.85 25.09-4.04 22.94-16.94L325.87 256H432c7.13 0 10.7-8.62 5.66-13.66L419.31 224l26.34-26.34a8.006 8.006 0 0 0 .01-11.32zM192 96c-8.84 0-16-7.16-16-16s7.16-16 16-16 16 7.16 16 16-7.16 16-16 16zm64 16c-8.84 0-16-7.16-16-16s7.16-16 16-16 16 7.16 16 16-7.16 16-16 16z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faScarecrow = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;