'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'omega';
var width = 512;
var height = 512;
var ligatures = [];
var unicode = 'f67a';
var svgPathData = 'M488 416h-32.61c42.89-53.17 65.05-123.68 53.64-199.4C492.12 104.36 399.19 14.85 286.45 1.77 131.74-16.18 0 104.82 0 256c0 60.59 21.27 116.18 56.61 160H24c-13.25 0-24 10.75-24 24v48c0 13.25 10.75 24 24 24h136c17.67 0 32-14.33 32-32v-42.7c0-20.53-11.09-38.78-27.88-50.59-48.22-33.92-76.98-93.67-65.67-159.06 10.89-62.93 60.5-114.85 122.99-128.01C324.68 77.9 416 156.49 416 256c0 54.44-27.4 102.51-69.08 131.38-16.49 11.43-26.92 29.63-26.92 49.7V480c0 17.67 14.33 32 32 32h136c13.25 0 24-10.75 24-24v-48c0-13.25-10.75-24-24-24z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faOmega = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;