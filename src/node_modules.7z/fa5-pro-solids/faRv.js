'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'rv';
var width = 640;
var height = 512;
var ligatures = [];
var unicode = 'f7be';
var svgPathData = 'M621.3 269.3L563 211c-12-12-28.4-18.8-45.4-18.8L416 192v240h.2c.1 34.1 22.1 66.3 54.9 76.2 54.8 16.6 105-23.9 105-76.2v-16h32c17.6 0 32-14.4 32-32v-69.5c-.1-17-6.8-33.2-18.8-45.2zM496 464c-17.6 0-32-14.4-32-32s14.4-32 32-32 32 14.4 32 32-14.4 32-32 32zm-16-176v-48h37.5c4.3 0 8.3 1.7 11.3 4.7l43.3 43.3H480zm128-160.8c-.4-52.6-43.2-95.2-96-95.2H384V16c0-8.8-7.2-16-16-16H240c-8.8 0-16 7.2-16 16v16H64C28.7 32 0 60.7 0 96v197.5c0 17 6.7 33.3 18.7 45.3L96 416v11.4c0 41.8 30.1 80 71.8 84.1 47.9 4.8 88.2-32.7 88.2-79.6v-16h128V160h192c17.9 0 32.1-14.8 32-32.8zM176 464c-17.6 0-32-14.4-32-32s14.4-32 32-32 32 14.4 32 32-14.4 32-32 32zm80-256c0 8.8-7.2 16-16 16H112c-8.8 0-16-7.2-16-16v-64c0-8.8 7.2-16 16-16h128c8.8 0 16 7.2 16 16v64z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faRv = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;