'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'turkey';
var width = 640;
var height = 512;
var ligatures = [];
var unicode = 'f725';
var svgPathData = 'M596.39 83.63c-8.27-1.51-16.36-.82-23.93 1.35 7.21-9.79 11.6-21.98 10.25-36.3-1.97-20.79-16.24-39.48-36.09-45.97-31.32-10.25-63.28 9.71-68.97 41.13-1.3 7.16-1.07 14.22.43 20.88 3.53 15.67-1.36 32.04-14.57 41.19-15.48 10.73-24.23 17.61-48.07 27.98C376.99 110.67 333.83 96 288 96 128.94 96 0 269.13 0 384s128.94 128 288 128 288-13.12 288-128c0-49.99-24.54-110.94-65.24-163.91-37.67 31.56-53.31 66.75-61 90.2-19.05 58.14-68.12 99.33-125.01 104.93-5.31.52-10.54.78-15.7.78-49.36 0-93.81-22.96-121.94-63-11.85-16.87-19.84-35.82-23.87-55.58-1-4.88 2.96-9.42 7.94-9.42h16.43c3.74 0 6.85 2.64 7.71 6.28 11.9 50.18 56.32 89.72 113.73 89.72 4.13 0 8.31-.2 12.56-.62 45.84-4.51 83.33-39.06 97.74-83.05 20.72-63.26 63.07-101.22 90.64-120.41 14.76-10.27 33.47-8.35 48.61 1.35 8.52 5.46 18.83 8.57 30.26 8.26 20.9-.57 40.12-14.38 47.52-33.94 12.22-32.3-7.86-66.09-39.99-71.96z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faTurkey = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;