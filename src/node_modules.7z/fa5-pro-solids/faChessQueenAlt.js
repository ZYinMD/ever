'use strict';
Object.defineProperty(exports, '__esModule', { value: true });
var prefix = 'fas';
var iconName = 'chess-queen-alt';
var width = 320;
var height = 512;
var ligatures = [];
var unicode = 'f446';
var svgPathData = 'M135.85 23.972C135.85 10.733 146.583 0 159.822 0s23.972 10.733 23.972 23.972-10.733 23.972-23.972 23.972-23.972-10.733-23.972-23.972zm128.98 414.032v-31.72a6 6 0 0 0-6-6H61.17a6 6 0 0 0-6 6v31.72l-24.819 15.872a6 6 0 0 0-2.767 5.055V506a6 6 0 0 0 6 6h252.833a6 6 0 0 0 6-6v-47.069a6 6 0 0 0-2.767-5.055l-24.82-15.872zM73.841 204.625l-.002 24.279a6 6 0 0 0 6 6h29.319c.247 35.972.196 99.658-19.168 156.552h140.03c-19.131-56.208-19.309-118.831-19.122-156.552h29.265a6 6 0 0 0 6-6l.002-24.279a6 6 0 0 0-6-6H79.841a6 6 0 0 0-6 6zm148.026-14.828l44.404-107.49a6 6 0 0 0-2.745-7.597l-15.39-8.123a5.997 5.997 0 0 0-8.024 2.355c-3.719 6.591-9.661 15.476-18.468 15.476-12.077 0-13.078-8.184-13.54-23.793a6.005 6.005 0 0 0-5.998-5.832h-16.095c-2.584 0-4.841 1.668-5.692 4.108-3.859 11.059-11.123 16.966-20.317 16.966s-16.457-5.907-20.317-16.966c-.851-2.44-3.108-4.108-5.692-4.108h-16.095a6.005 6.005 0 0 0-5.998 5.833c-.458 15.57-1.448 23.792-13.541 23.792-8.588 0-14.131-8.139-18.6-15.58a5.999 5.999 0 0 0-7.946-2.222L56.479 74.71a6 6 0 0 0-2.745 7.597l44.404 107.49h123.729z';

exports.definition = {
  prefix: prefix,
  iconName: iconName,
  icon: [
    width,
    height,
    ligatures,
    unicode,
    svgPathData
  ]};

exports.faChessQueenAlt = exports.definition;
exports.prefix = prefix;
exports.iconName = iconName;
exports.width = width;
exports.height = height;
exports.ligatures = ligatures;
exports.unicode = unicode;
exports.svgPathData = svgPathData;